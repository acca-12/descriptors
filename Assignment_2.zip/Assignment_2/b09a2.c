#include "b09a2.h"

bool checkIfStringIsNumber(char *string){
    /* 
        @brief: checks if char *string is a number 
        @param: char* to a string
        @return: return true iff every character in char* (up to null) is a number
    */


    //goes until delimeter is reached '\0' has value 0
    while(*string){
        //first occurence of non numeric character will return false
        if(!isdigit(*string)){
            return false;
        }
        //goes to next character
        string = string + sizeof(char);
    }
    //code will only reach this if every character is indeed a digit
    return true;
}




FileDescriptor *newFD(int integer_value, char *name, ino_t inode){
    /*
        @brief: Creates a new FileDescriptor struct given the value, file name, and inode 
        @param: the file descriptor integer value
                the file name associated with it
                the inode of file

        @return: the node given the paramater values
    */

    FileDescriptor *fd = (FileDescriptor *)malloc(sizeof(FileDescriptor));
    if(fd == NULL){
        fprintf(stderr, "malloc failed");
        exit(EXIT_FAILURE);
    }
    fd->integer_value = integer_value;
    fd->name = malloc(sizeof(char) * strlen(name) + 1);
    if(fd->name == NULL){
        fprintf(stderr, "malloc failed");
        exit(EXIT_FAILURE);
    }
    strcpy(fd->name, name);
    fd->inode = inode;
    fd->next = NULL;
    return fd;

}

ProcessNode* newNode(pid_t pid, FileDescriptor *descriptors_head){
    /*
        @brief: Creates a new ProcessNode struct given the pid, and descriptors_head which is the head
        to the linked list of file descriptors this process has

        @param: a pid for a process 
                pointer to head of descriptors linked list

        @return: head to linked list with add appended
    */
    ProcessNode *process = (ProcessNode *)malloc(sizeof(ProcessNode));
    if(process == NULL){
        fprintf(stderr, "malloc failed");
        exit(EXIT_FAILURE);
    }
    process->pid = pid;
    process->descriptors = descriptors_head;
    process->next = NULL;
    return process;
}

FileDescriptor* insert(FileDescriptor *head, FileDescriptor *add){
    /*
        @brief: Inserts add at the tail of FileDescriptor head

        @param: head of linked list to FileDescriptor
                FileDescriptor to add to linked list
        
        @return: head to linked list with add appended
    */

    if(head == NULL)
        return add;

    FileDescriptor *trace = head;
    while(trace->next != NULL){
        trace = trace->next;
    }
    trace->next = add;
    return head;
}

ProcessNode* insertProcess(ProcessNode *head, ProcessNode *add){
    /*
        @brief: Inserts add at the tail of ProcessNode head

        @param: head of linked list to ProcessNode
                ProcessNode to add to linked list
        
        @return: head to linked list with add appended
    */
    if(head == NULL)
        return add;

    ProcessNode *trace = head;
    while(trace->next != NULL){
        trace = trace->next;
    }
    trace->next = add;
    return head;
}

ProcessNode *search(ProcessNode *head, int pid_positional){
    /*
        @brief: Searches the ProcessNode linked list for pid_positional

        @param: ProcessNode linked list
                pid to search for
        
        @return: if found, return the node
                 otherwise, returns NULL
    */
    if(head == NULL)
        return NULL;
    while(head != NULL){
        if (head->pid == pid_positional)
            return head;
        head = head->next;
    }
    return NULL;
}

FileDescriptor* fillInformation(FileDescriptor* process_descriptors_head, char *path_name, char *pid){
    /*
        @brief: iterates through each file descriptor found for a process with pid pid
        and intializes and links them for that process

        @param: head of file descriptor list we will build
                path to fd subdirectory
                pid of process

        @return: FULL file descriptor linked list for a process    
    */


    DIR *fd_subdirectory = opendir(path_name);
    

    //some user processes are not accessible, in this case just skip over by setting errno to 0
    if(errno == EACCES){
        errno = 0;
        return NULL;
    }else{
        struct dirent *read_file_descriptors = readdir(fd_subdirectory);
        //loop to iterate through each fd in the fd subdirectory 
        while(read_file_descriptors != NULL){
            //if digit then must be an fd
            if(isdigit(read_file_descriptors->d_name[0])){
                //intialize variables to use for later
                struct stat file_inode;
                struct stat link;
                char *file_name;
                ino_t inode;
                size_t bufsize;
                size_t bytes;
                //change path_name to specific fd
                snprintf(path_name, PATH_MAX, "/proc/%s/fd/%s", pid, read_file_descriptors->d_name);


                if(stat(path_name, &file_inode) == -1){
                    fprintf(stderr, "error stating file : %d", errno);
                    exit(EXIT_FAILURE);
                }
                //stat to get inode, stat skips over the link and goes straight to fd
                inode = file_inode.st_ino;

                //lstat to get filename
                if(lstat(path_name, &link) == -1){
                    fprintf(stderr, "error stating file : %d", errno);
                    exit(EXIT_FAILURE);
                }
                //initiliaze enough characters to readlink
                bufsize = link.st_size + 1;

                file_name = malloc(bufsize * sizeof(char));
                if(file_name == NULL){
                    fprintf(stderr, "malloc failed");
                    exit(EXIT_FAILURE);
                }
                //readlink save file_name to file_name
                bytes = readlink(path_name, file_name, bufsize);
                if(bytes == -1){
                    fprintf(stderr, "readlink error");
                    exit(EXIT_FAILURE);
                }
                //make sure last is a null character
                file_name[bufsize] = '\0';

                //create new fd using info found
                FileDescriptor *new_fd = newFD(atoi(read_file_descriptors->d_name), file_name, inode);
                //insert new fd to the linked list to eventually get linked list of all fd for process
                process_descriptors_head = insert(process_descriptors_head, new_fd);
                //free malloc
                free(file_name);

            }
            read_file_descriptors = readdir(fd_subdirectory);
        }
    }
    //close directory
    closedir(fd_subdirectory);
    return process_descriptors_head;
}



void printPerProcDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid){
    /*
        @brief: prints  processes' (identified by pid) file descriptors
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
    */
    while(head != NULL){
        if(positional)
            printf("        %d  %d\n", pid, head->integer_value);
        else{
            printf("%d        %d  %d\n", *entry, pid, head->integer_value);
            *entry += 1;
        }
        head = head->next; 
    }
    
}

void printSysWideDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid){
    /*
        @brief: prints  processes' (identified by pid) file descriptors with the file name
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
    */
    while(head != NULL){
        if(positional)
            printf("        %d  %d         %s\n", pid, head->integer_value, head->name);
        else{
            printf("%d        %d  %d         %s\n", *entry, pid, head->integer_value, head->name);
            *entry += 1;
        }
        head = head->next; 
    }
    
}

void printVnodesDescriptors(FileDescriptor *head, int positional, int *entry){
    /*
        @brief: prints processes' (identified by pid) file descriptors with the vnodes asssoicated to them
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
    */
    while(head != NULL){
        if(positional)
            printf("        %d      %ld\n", head->integer_value,  (long) head->inode);
        else{
            printf("%d        %d      %ld\n", *entry, head->integer_value, (long) head->inode);
            *entry += 1;
        }
        head = head->next;
    }

}

void printCompositeDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid){
    /*
        @brief: prints processes' (identified by pid) file descriptors with the file name and vnode
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
    */
    while(head != NULL){
        if(positional)
            printf("        %d  %d         %s      %ld\n", pid, head->integer_value, head->name, (long) head->inode);
        else{
            printf("%d        %d  %d         %s      %ld\n", *entry, pid, head->integer_value, head->name, (long) head->inode);
            *entry += 1;
        }
        head = head->next; 
    }
}

int largerThanThreshold(FileDescriptor *head, int threshhold){
    /*
        @brief: sees if a process has a number of file descriptors greater than threshold
        @param: FileDescriptor head to go over the enitre linked list
        @return: returns the number of items in the linked list
    */
    int fd_counter = 0;

    while(head != NULL){
        fd_counter++;
        head = head->next;
    }

    if(fd_counter > threshhold)
        return fd_counter;
    return 0;
}

void printPerProcess(ProcessNode *head, int positional, int pid_positional){
    /*
        @brief: iterates over the ProcessNode linked list to print each per process table
        @param: ProcessNode head to go over the enitre linked list
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print
    */
    int entry_number = 0;
    if(positional){
        //if positional, search for that process in linked list 
        head = search(head, pid_positional);
        if(head != NULL){
            //if found only print it
            printPerProcDescriptors(head->descriptors, positional, &entry_number, head->pid);
        }else{
            //process with pid pid not user process
            fprintf(stderr, "PID NOT  CURRENT USER'S/DOESN'T EXIST\n");
            exit(EXIT_FAILURE);
        }
        
    }else{
        //if not positional then iterate through everything
        while(head != NULL){
            FileDescriptor *fd_head = head->descriptors;
            printPerProcDescriptors(fd_head, 0, &entry_number, head->pid);
            head = head->next;
        }
    }
}


void printSystemWide(ProcessNode *head, int positional, int pid_positional){
    /*
        @brief: iterates over the ProcessNode linked list to print each systemWide table
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

    */

    //analogical to previous
    int entry_number = 0;
    if(positional){
        head = search(head, pid_positional);
        if(head != NULL){
            printSysWideDescriptors(head->descriptors, positional, &entry_number, head->pid);
        }else{
            fprintf(stderr, "PID NOT  CURRENT USER'S/DOESN'T EXIST\n");
            exit(EXIT_FAILURE);;
        }
    }else{
        while(head != NULL){
            FileDescriptor *fd_head = head->descriptors;
            printSysWideDescriptors(fd_head, 0, &entry_number, head->pid);
            head = head->next;
        }
    }
}
void printVnodes(ProcessNode *head, int positional, int pid_positional){
    /*
        @brief: iterates over the ProcessNode linked list to print vnode table
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

    */

    //analogical to previous
    int entry_number = 0;
    if(positional){
        head = search(head, pid_positional);
        if(head != NULL){
            printVnodesDescriptors(head->descriptors, positional, &entry_number);
        }else{
            fprintf(stderr, "PID NOT  CURRENT USER'S/DOESN'T EXIST\n");
            exit(EXIT_FAILURE);
        }
    }else{
        while(head != NULL){
            FileDescriptor *fd_head = head->descriptors;
            printVnodesDescriptors(fd_head, 0, &entry_number);
            head = head->next;
        }
    }
    
}
void printComposite(ProcessNode *head, int positional, int pid_positional){
    /*
        @brief: iterates over the ProcessNode linked list to print each process systemwide
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

    */

    //analogical to previous
    int entry_number = 0;
    if(positional){
        head = search(head, pid_positional);
        if(head != NULL){
            printCompositeDescriptors(head->descriptors, positional, &entry_number, head->pid);
        }else{
            fprintf(stderr, "PID SPECIFIED NOT CURRENT USER'S/DOESN'T EXIST\n");
            exit(EXIT_FAILURE);
        }
    }else{
        while(head != NULL){
            FileDescriptor *fd_head = head->descriptors;
            printCompositeDescriptors(fd_head, 0, &entry_number, head->pid);
            head = head->next;
        }
    }
}

void printThreshold(ProcessNode *head, int threshold){
    while(head != NULL){
        FileDescriptor *fd_head = head->descriptors;
        int x;
        if((x = largerThanThreshold(fd_head, threshold))){
            printf("%d (%d) \n", head->pid, x);
        }
        head = head->next;
    }
    
}

void deleteDescriptorList(FileDescriptor *head){
    //simple function to delete entire list
    FileDescriptor *current = head;
    FileDescriptor *next;
    
    while(current != NULL){
        next = current->next;
        free(current);
        current = next;
    }

}

void deleteProcessList(ProcessNode *head){

    ProcessNode *current = head;
    ProcessNode *next;
    
    while(current != NULL){
        next = current->next;
        deleteDescriptorList(current->descriptors);
        free(current);
        current = next;
    }

}



