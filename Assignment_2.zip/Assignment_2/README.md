# SYSTEM WIDE FD TABLE

## The Problem
	
	Disclaimer: the important assumption to skip over a handful of user processes is taken via
	piazza post. I set errno to 0 after seeing it errored to EACCESS.
	
	We aim to esentially print out for each current user process' file descriptors, inodes, 
	and file names
	
	The problem for this assignment (CLA excluded) lies in the fact that we have to read 
	several directories. We have only dealt with files  before and though files = 
	directories in LINUX, reading them in C is different. To do this we had to use dirrent.h
	to be able to open up a directory and read the directory.
	
	We note that /proc linux page describes all the data and what can be done to retrieve 
	them. Specifically, they say that /proc is a directory containing the potential 
	processes we want to retireve information about.
	
	
	# Retrieving Information
	
	For this particular project we are interested in the current user processes. We have 
	noted that we can access the processes in the /proc/[pid] subdirectory. It is important 
	to know that we can call stat on this path and  essentially retrieve the owner of the 
	process. Through this, it is a matter of a simple comparison between the user
	id and the retrieved id.
	
	If the retreived id is equal to the user id. We then want to look at that particular process.
	
	First however, we should decide how to store the information.
	
	I decided on a linked list of processes which contain their unique pid, and a linked list
	 of all their file
	descriptors. 
	
	It is quite easy to see how benefical this would be. since each file descriptor has its 
	own fields, it makes sense to also make a linked list out of its struct, especially 
	since we are not too sure about how many file descriptors  there actually are through 
	/proc/[pid]/status
	
	We then solve the problem of populating the fields we want. Specifically we want to retrieve 
	the assigned integer to the file descriptor, the file name, and the inode.
	
	Doing this is identical to the process of seeing if the owner id of a proc matches the user.
	
	We open the subdirectory /proc/[pid]/fd and as per linux documentation read each directory 
	in the directory and using lstat and stat to retrieve information. We use stat to retrieve the 
	inode and lstat to retrieve the file name, as documentation specifies that it is a symbolic 
	link. Note stat goes through symbolic link hence we can get the inode, but not the file
	 name -- this is done with lstat, as mentioned.
	
	From there we just populate and iterate.
	
	The next problem is the situation of CLA. Very similar to A1, we just use a for loop setting
	truth values to 1 if we see them. We note that composite is the default output. 
	
	For whatever is set to true we simply call the corresponding print function to that CLA.
	
## Function overview

        brief: Creates a new FileDescriptor struct given the value, file name, and inode 
        param: the file descriptor integer value
                the file name associated with it
                the inode of file

        return: the node given the paramater values


### FileDescriptor \*newFD(int integer_value, char \*name, ino_t inode);



        brief: Creates a new ProcessNode struct given the pid, and descriptors_head which is the head
        to the linked list of file descriptors this process has

        param: a pid for a process 
                pointer to head of descriptors linked list

        return: head to linked list with add appended


### ProcessNode\* newNode(int pid, FileDescriptor \*self);



        brief: Inserts add at the tail of FileDescriptor head

        param: head of linked list to FileDescriptor
                FileDescriptor to add to linked list
        
        return: head to linked list with add appended


### FileDescriptor\* insert(FileDescriptor \*head, FileDescriptor \*add);



        brief: Inserts add at the tail of ProcessNode head

        param: head of linked list to ProcessNode
                ProcessNode to add to linked list
        
        return: head to linked list with add appended


### ProcessNode\* insertProcess(ProcessNode \*head, ProcessNode \*add);




        brief: Searches the ProcessNode linked list for pid_positional

        param: ProcessNode linked list
                pid to search for
        
        return: if found, return the node
                 otherwise, returns NULL


### ProcessNode \*search(ProcessNode \*head, int pid_positional);




        brief: iterates through each file descriptor found for a process with pid pid
        and intializes and links them for that process

        param: head of file descriptor list we will build
                path to fd subdirectory
                pid of process

        return: FULL file descriptor linked list for a process    


### FileDescriptor\* fillInformation(FileDescriptor\* process_descriptors_head, char \*path_name, char \*pid);



        brief: prints  processes' (identified by pid) file descriptors
        param: FileDescriptor head to go over the enitre linked list
        return: void, it prints the information


### void printPerProcDescriptors(FileDescriptor \*head, int positional, int \*entry, pid_t pid);



        brief: prints  processes' (identified by pid) file descriptors with the file name
        param: FileDescriptor head to go over the enitre linked list
        return: void, it prints the information


### void printSysWideDescriptors(FileDescriptor \*head, int positional, int \*entry, pid_t pid);


        brief: prints processes' (identified by pid) file descriptors with the vnodes asssoicated to them
        param: FileDescriptor head to go over the enitre linked list
        return: void, it prints the information


### void printVnodesDescriptors(FileDescriptor \*head, int positional, int \*entry);



        brief: prints processes' (identified by pid) file descriptors with the file name and vnode
        param: FileDescriptor head to go over the enitre linked list
        return: void, it prints the information


### void printCompositeDescriptors(FileDescriptor \*head, int positional, int \*entry, pid_t pid);


        brief: sees if a process has a number of file descriptors greater than threshold
        param: FileDescriptor head to go over the enitre linked list
        return: returns the number of items in the linked list


### int largerThanThreshold(FileDescriptor \*head, int threshhold);




        brief: iterates over the ProcessNode linked list to print each per process table
        param: ProcessNode head to go over the enitre linked list
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        return: void, used to iterate and print


### void printPerProcess(ProcessNode \*head, int positional, int pid_positional);


        brief: iterates over the ProcessNode linked list to print each systemWide table
        param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        return: void, used to iterate and print



### void printSystemWide(ProcessNode \*head, int positional, int pid_positional);


        brief: iterates over the ProcessNode linked list to print vnode table
        param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        return: void, used to iterate and print



### void printVnodes(ProcessNode \*head, int positional, int pid_positional);


        brief: iterates over the ProcessNode linked list to print each process composite
        param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        return: void, used to iterate and print



### void printComposite(ProcessNode \*head, int positional, int pid_positional);



        brief: prints all processes who has more file descriptors than threshold with the number it has

        param: Head of process linked list and threshold

        return: void, prints all offending processes
    


### void printThreshold(ProcessNode \*head, int threshold);

 //simple function to delete entire list

### void deleteDescriptorList(FileDescriptor \*head);

 //simple function to delete entire list (calls deleteDescriptor)

### void deleteProcessList(ProcessNode \*head_ref);

## How To Run
	
	In the terminal...
	
	Go to directory where b09a2.c b09a2.h a2_main.c makefile are in
	
	make a2
	
	/a2 flags
	
	where -flags are a combination of any of the flags described in the assignment description
	with a few exceptions
	
	--per-process is valid
	--Vnodes is valid
	--systemWide is valid
	--threshold=X is valid, where X >=0
	--composite is valid
	
	The few exceptions are listed as below, as well as design choices made!
	
	
	DISCLAIMER:

		I have assumed the following flags are invalid:
			two positional arguments
		
		For the following flags I make an assumption that sites to the number beside:
		
			(1) --threshold=X
			(2) positional argument
		
		(1) and (2) SINCE these are not table arguments if the only CLA is one of or a combination
		of these two then composite table will print
		
		(1) you can use this flag multiple times, it thresholds THE LATEST threshold CLA
		ALSO, this flag only works with 0 and positive integers. This is a design choice
		
		
		
		
	

	



