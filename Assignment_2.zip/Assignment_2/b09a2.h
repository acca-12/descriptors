#include <errno.h>
#include <pwd.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <grp.h>
#include <stdio.h>
#include <ctype.h>
#include <linux/limits.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


#ifndef B09A2_H_   /* Include guard */
#define B09A2_H_

bool checkIfStringIsNumber(char *string);

typedef struct file_descriptor{
    /*
        CDT for file_descriptor
    */
    int integer_value;
    char* name;
    ino_t inode;
    struct file_descriptor *next;
}FileDescriptor;



typedef struct processes_node{
    /*
        CDT for process_node
        for each process we should store the pid
        and a linked list of file descriptors
    */
    pid_t pid;
    FileDescriptor* descriptors;
    struct processes_node *next;
}ProcessNode;


/* 
        @brief: checks if char *string is a number 
        @param: char* to a string
        @return: return true iff every character in char* (up to null) is a number
*/
bool checkIfStringIsNumber(char *string);


/*
        @brief: Creates a new FileDescriptor struct given the value, file name, and inode 
        @param: the file descriptor integer value
                the file name associated with it
                the inode of file

        @return: the node given the paramater values
*/
FileDescriptor *newFD(int integer_value, char *name, ino_t inode);


/*
        @brief: Creates a new ProcessNode struct given the pid, and descriptors_head which is the head
        to the linked list of file descriptors this process has

        @param: a pid for a process 
                pointer to head of descriptors linked list

        @return: head to linked list with add appended
*/
ProcessNode* newNode(int pid, FileDescriptor *self);


/*
        @brief: Inserts add at the tail of FileDescriptor head

        @param: head of linked list to FileDescriptor
                FileDescriptor to add to linked list
        
        @return: head to linked list with add appended
*/
FileDescriptor* insert(FileDescriptor *head, FileDescriptor *add);

/*
        @brief: Inserts add at the tail of ProcessNode head

        @param: head of linked list to ProcessNode
                ProcessNode to add to linked list
        
        @return: head to linked list with add appended
*/
ProcessNode* insertProcess(ProcessNode *head, ProcessNode *add);


/*
        @brief: Searches the ProcessNode linked list for pid_positional

        @param: ProcessNode linked list
                pid to search for
        
        @return: if found, return the node
                 otherwise, returns NULL
*/
ProcessNode *search(ProcessNode *head, int pid_positional);

/*
        @brief: iterates through each file descriptor found for a process with pid pid
        and intializes and links them for that process

        @param: head of file descriptor list we will build
                path to fd subdirectory
                pid of process

        @return: FULL file descriptor linked list for a process    
*/
FileDescriptor* fillInformation(FileDescriptor* process_descriptors_head, char *path_name, char *pid);


/*
        @brief: prints  processes' (identified by pid) file descriptors
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
*/
void printPerProcDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid);

/*
        @brief: prints  processes' (identified by pid) file descriptors with the file name
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
*/
void printSysWideDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid);

/*
        @brief: prints processes' (identified by pid) file descriptors with the vnodes asssoicated to them
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
*/
void printVnodesDescriptors(FileDescriptor *head, int positional, int *entry);

/*
        @brief: prints processes' (identified by pid) file descriptors with the file name and vnode
        @param: FileDescriptor head to go over the enitre linked list
        @return: void, it prints the information
*/
void printCompositeDescriptors(FileDescriptor *head, int positional, int *entry, pid_t pid);

/*
        @brief: sees if a process has a number of file descriptors greater than threshold
        @param: FileDescriptor head to go over the enitre linked list
        @return: returns the number of items in the linked list
*/
int largerThanThreshold(FileDescriptor *head, int threshhold);

/*
        @brief: iterates over the ProcessNode linked list to print each per process table
        @param: ProcessNode head to go over the enitre linked list
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print
*/
void printPerProcess(ProcessNode *head, int positional, int pid_positional);

/*
        @brief: iterates over the ProcessNode linked list to print each systemWide table
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

*/
void printSystemWide(ProcessNode *head, int positional, int pid_positional);

/*
        @brief: iterates over the ProcessNode linked list to print vnode table
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

*/
void printVnodes(ProcessNode *head, int positional, int pid_positional);

/*
        @brief: iterates over the ProcessNode linked list to print each process systemwide
        @param: ProcessNode head to go over the enitre linked list 
                if positional argument is specifiec then it only prints that process
                pid_postional specifices what to search for in linked list 
        @return: void, used to iterate and print

*/
void printComposite(ProcessNode *head, int positional, int pid_positional);

/*
        @brief: prints all processes who has more file descriptors than threshold with the number it has

        @param: Head of process linked list and threshold


        @return: void, prints all offending processes
*/
void printThreshold(ProcessNode *head, int threshold);

//simple function to delete entire list
void deleteDescriptorList(FileDescriptor *head);

//simple function to delete entire list (calls deleteDescriptorList)
void deleteProcessList(ProcessNode *head_ref);

#endif