#include "b09a2.h"


int main(int argc, char **argv){

    //information handling
    ProcessNode *head = NULL;
    DIR *process = opendir("/proc");
    uid_t uid = getuid();

    if(process == NULL){
        fprintf(stderr, "Error opening /proc");
        exit(EXIT_FAILURE);
    }

    struct dirent *read_proc = readdir(process);
    //iterate over /proc
    while(read_proc != NULL){
        if (isdigit(read_proc->d_name[0])){
            char path_name[PATH_MAX];
            struct stat sb;
            snprintf(path_name, PATH_MAX, "/proc/%s", read_proc->d_name);
            //call stat to get id of owner of proc
            stat(path_name, &sb);
            //if same id as user running program then collect information
            if(sb.st_uid == uid){
                FileDescriptor *head_descriptor = NULL;
                snprintf(path_name, PATH_MAX, "/proc/%s/fd", read_proc->d_name);
                //fills the FileDescriptor linked list with all the fds associated to that proc
                head_descriptor = fillInformation(head_descriptor, path_name, read_proc->d_name);
                //we have to skip some, so we consider the null case, in the case that we iterated over
                //something we dont have to skip then we can insert the new node
                if(head_descriptor != NULL){
                    ProcessNode *new_proc = newNode(atoi(read_proc->d_name), head_descriptor);
                    head = insertProcess(head, new_proc);
                }

            }

        }
        read_proc = readdir(process);
    }
    closedir(process);

    //CLA handling
    int composite = 0;
    int per_process = 0;
    int vnodes = 0;
    int system_wide = 0;
    int set_threshold = 0;
    int threshold = 0;
    int positional = 0;
    int pid_positional = 0;

    if(argc == 1){
        //default behaviour is composite table
        printComposite(head, positional, pid_positional);
    }else{
        for(int i = 1; i < argc; i++){
            if(strcmp(argv[i], "--per-process") == 0){
                per_process = 1;
            }else if(strcmp(argv[i], "--systemWide") == 0){
                system_wide = 1;
            }else if(strcmp(argv[i], "--Vnodes") == 0){
                vnodes = 1;
            }else if(strcmp(argv[i], "--composite") == 0){
                composite = 1;
            }else if((strncmp(argv[i], "--threshold=", 12) == 0) && (argv[i][12] != '\0')){
                char *traverse = argv[i] + sizeof(char) * 12;
                if(checkIfStringIsNumber(traverse)){
                    //set threshold
                    threshold = atoi(traverse);
                }else{
                    //invalid flag, doesn't contain all numbers after =
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                set_threshold = 1;
            //guarantees that you can only specify one positional argument, if you have more then this is invalid
            }else if(positional == 0 && isdigit(argv[i][0])){
                char *traverse = argv[i];
                //makes sure the whole number is a number otherwise send out an error
                if(checkIfStringIsNumber(traverse)){
                    pid_positional = atoi(traverse);
                }else{
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                positional = 1;
            //anything else is an invalid flag
            }else{
                fprintf(stderr, "Invalid flag");
                exit(EXIT_FAILURE);
            }

        }
        //self-explanatory, if the value is set, then we print it
        if(per_process){
                printf("         PID     FD\n");
                printf("        ============\n");
                printPerProcess(head, positional, pid_positional);
                printf("        ===============================================\n");
            }

            if(system_wide){
                printf("         PID     FD      Filename\n");
                printf("        ========================================\n");
                printSystemWide(head, positional, pid_positional);
                printf("        ===============================================\n");
            }

            if(vnodes){
                printf("           FD            Inode\n");
                printf("        ========================================\n");
                printVnodes(head, positional, pid_positional);
                printf("        ===============================================\n");
            }

            if(composite){
                printf("         PID     FD      Filename                Inode\n");
                printf("        ===============================================\n");
                printComposite(head, positional, pid_positional);
                printf("        ===============================================\n");
            }

            if(!per_process && !system_wide && ! vnodes && (positional || set_threshold)){
                printf("         PID     FD      Filename                Inode\n");
                printf("        ===============================================\n");
                printComposite(head, positional, pid_positional);
                printf("        ===============================================\n");
            }

            if(set_threshold){
                printf("### Offending Processes ###\n");
                printf("=======================================================\n");
                printThreshold(head, threshold);
                printf("=======================================================\n");
            }
    }
    deleteProcessList(head);
}